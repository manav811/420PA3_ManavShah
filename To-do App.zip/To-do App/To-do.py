import json
import os
from datetime import datetime

TASKS_FILE = "tasks.json"

def load_tasks():
    if not os.path.exists(TASKS_FILE):
        return []
    try:
        with open(TASKS_FILE, "r") as file:
            return json.load(file)
    except json.JSONDecodeError:
        print("⚠️ Warning: tasks.json is empty or corrupt. Starting with an empty list.")
        return []

def save_tasks(tasks):
    with open(TASKS_FILE, "w") as file:
        json.dump(tasks, file, indent=4)

def list_tasks(tasks):
    if not tasks:
        print("No tasks found.")
        return
    print("\n--- TASK LIST ---")
    for task in tasks:
        status = "✔" if task["completed"] else "✘"
        print(f"ID: {task['id']} | [{status}] {task['description']}")
        print(f"    Priority: {task['priority']} | Due: {task['due_date']} | Created: {task['created_at']}")

def add_task(tasks):
    desc = input("Enter task description: ").strip()
    due_date = input("Enter due date (YYYY-MM-DD) or leave blank: ").strip()
    priority = input("Enter priority (High/Medium/Low): ").strip().capitalize()

    task_id = tasks[-1]["id"] + 1 if tasks else 1
    task = {
        "id": task_id,
        "description": desc,
        "completed": False,
        "created_at": datetime.now().strftime("%Y-%m-%d %H:%M"),
        "due_date": due_date if due_date else "None",
        "priority": priority if priority in ["High", "Medium", "Low"] else "Medium"
    }

    tasks.append(task)
    save_tasks(tasks)
    print("Task added.")

def edit_task(tasks):
    list_tasks(tasks)
    task_id = int(input("Enter task ID to edit: "))
    for task in tasks:
        if task["id"] == task_id:
            task["description"] = input("Enter new description: ").strip()
            task["due_date"] = input("Enter new due date (YYYY-MM-DD) or leave blank: ").strip() or "None"
            task["priority"] = input("Enter new priority (High/Medium/Low): ").strip().capitalize() or "Medium"
            save_tasks(tasks)
            print("Task updated.")
            return
    print("Task not found.")

def delete_task(tasks):
    list_tasks(tasks)
    task_id = int(input("Enter task ID to delete: "))
    for i, task in enumerate(tasks):
        if task["id"] == task_id:
            del tasks[i]
            save_tasks(tasks)
            print("Task deleted.")
            return
    print("Task not found.")

def mark_complete(tasks):
    list_tasks([t for t in tasks if not t["completed"]])
    task_id = int(input("Enter task ID to mark as completed: "))
    for task in tasks:
        if task["id"] == task_id:
            task["completed"] = True
            save_tasks(tasks)
            print("Task marked as completed.")
            return
    print("Task not found.")

def reopen_task(tasks):
    list_tasks([t for t in tasks if t["completed"]])
    task_id = int(input("Enter ID of task to reopen: "))
    for task in tasks:
        if task["id"] == task_id and task["completed"]:
            task["completed"] = False
            save_tasks(tasks)
            print("Task reopened.")
            return
    print("Task not found or already open.")

def filter_tasks(tasks):
    choice = input("Filter by (status/priority): ").strip().lower()
    if choice == "status":
        status = input("Enter 'completed' or 'pending': ").strip().lower()
        filtered = [t for t in tasks if (t["completed"] and status == "completed") or
                                        (not t["completed"] and status == "pending")]
    elif choice == "priority":
        level = input("Enter priority (High/Medium/Low): ").capitalize()
        filtered = [t for t in tasks if t["priority"] == level]
    else:
        print("Invalid filter type.")
        return

    list_tasks(filtered)

def main():
    tasks = load_tasks()
    while True:
        print("\n--- TO-DO LIST MENU ---")
        print("1. List Tasks")
        print("2. Add Task")
        print("3. Edit Task")
        print("4. Delete Task")
        print("5. Mark Task as Completed")
        print("6. Reopen Completed Task")
        print("7. Filter Tasks")
        print("8. Exit")
        choice = input("Choose an option: ")

        if choice == "1":
            list_tasks(tasks)
        elif choice == "2":
            add_task(tasks)
        elif choice == "3":
            edit_task(tasks)
        elif choice == "4":
            delete_task(tasks)
        elif choice == "5":
            mark_complete(tasks)
        elif choice == "6":
            reopen_task(tasks)
        elif choice == "7":
            filter_tasks(tasks)
        elif choice == "8":
            print("Goodbye!")
            break
        else:
            print("Invalid choice. Try again.")

if __name__ == "__main__":
    main()
