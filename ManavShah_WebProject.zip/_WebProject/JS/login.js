$(document).ready(function() {
    load();
  
    $('#login-btn').click(function() {
      authenticate_login();
    });
  
    $('#create-btn').click(function() {
      create_account();
    });
  
    $('#logout-btn').click(function() {
      authenticate_logout();
    });
  });
  
    function load() {
    var storedUsername = localStorage.getItem('username');
    if (storedUsername != null) {
        document.getElementById('uname').innerHTML = 'Logged in as: ' + storedUsername;
        document.getElementById('user').value = storedUsername;
        document.getElementById('pwd').value = '';
        $(".login").hide();
        $(".logout").show();
    } else {
      $(".login").hide();
        $(".logout").show();
        //document.getElementById('user').disabled = false;
        //document.getElementById('pwd').disabled = false;
        //document.getElementById('b1').disabled = false;
    }
}

function authenticate_login() {
    var username = document.getElementById('user').value;
    var password = document.getElementById('pwd').value;
    var correctUsername = "Manav@proj24.com";
    var correctPassword = "459ABC";

    if (username == correctUsername && password == correctPassword) {
        localStorage.setItem('username', username);
        document.getElementById('uname').innerHTML = 'Logged in as: ' + username;
        document.getElementById('user').disabled = true;
        document.getElementById('pwd').disabled = true;
        document.getElementById('b1').disabled = true;
    } else {
        alert('Invalid Username or Password or Use :Manav@proj24.com and 459ABC');
    }
}

function authenticate_logout() {
    localStorage.removeItem('username');
    document.getElementById('uname').innerHTML = '';
    document.getElementById('user').disabled = false;
    document.getElementById('pwd').disabled = false;
    document.getElementById('b1').disabled = false;
    document.getElementById('user').value = '';
    document.getElementById('pwd').value = '';
    $(document).ready(function(){
      $(".login").hide();
      $(".logout").show();
    });
}
