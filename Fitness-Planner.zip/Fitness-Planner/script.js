const plans = {
  muscle: [
    { day: "Monday", workout: "Chest & Triceps", details: "Bench Press – 4x10\nIncline Dumbbell Press – 3x12\nDips – 3x15" },
    { day: "Tuesday", workout: "Back & Biceps", details: "Pull-ups – 4x10\nBarbell Rows – 3x12\nHammer Curls – 3x15" },
    { day: "Wednesday", workout: "Legs", details: "Squats – 4x10\nLunges – 3x12 (each leg)\nLeg Press – 3x15" },
    { day: "Thursday", workout: "Shoulders", details: "Shoulder Press – 4x10\nLateral Raises – 3x15\nRear Delt Fly – 3x12" },
    { day: "Friday", workout: "Full Body Strength", details: "Deadlift – 4x6\nPush Press – 3x8\nFarmer's Walk – 3 rounds" },
    { day: "Saturday", workout: "Cardio + Core", details: "30 min HIIT\nPlank – 3x1 min\nRussian Twists – 3x20" },
    { day: "Sunday", workout: "Rest", details: "Stretching, Walking, Recovery" }
  ],
  fat: [
    { day: "Monday", workout: "HIIT", details: "Jump Squats – 3x20\nMountain Climbers – 4x30s\nBurpees – 3x15" },
    { day: "Tuesday", workout: "Core", details: "Plank – 3x1 min\nLeg Raises – 3x15\nBicycle Crunch – 3x20" },
    { day: "Wednesday", workout: "Cardio", details: "Jog – 40 min\nJump Rope – 5x1 min\nStair Climbs – 3 rounds" },
    { day: "Thursday", workout: "Upper Body Strength", details: "Push-ups – 4x15\nResistance Band Rows – 3x12\nDumbbell Shoulder Press – 3x10" },
    { day: "Friday", workout: "Lower Body Burn", details: "Step-ups – 3x20\nLunges – 3x12 each\nGlute Bridges – 3x15" },
    { day: "Saturday", workout: "Stretch & Mobility", details: "30 min Yoga\nFoam Rolling – Full Body\nDeep Squat Hold – 3x30s" },
    { day: "Sunday", workout: "Active Rest", details: "Walk – 45 min\nLight Stretching" }
  ],
  fit: [
    { day: "Monday", workout: "Bodyweight Circuit", details: "Push-ups – 3x15\nAir Squats – 3x20\nSit-ups – 3x20" },
    { day: "Tuesday", workout: "Cardio", details: "Brisk Walk or Light Jog – 30 min\nJump Rope – 3x1 min" },
    { day: "Wednesday", workout: "Stretch & Strength", details: "Yoga – 45 min\nBodyweight Lunges – 3x15\nSuperman Hold – 3x30s" },
    { day: "Thursday", workout: "Upper Body Maintenance", details: "Resistance Band Rows – 3x12\nWall Push-ups – 3x20\nOverhead Reach – 3x15" },
    { day: "Friday", workout: "Full Body HIIT", details: "Jumping Jacks – 3x50\nLunges – 3x12\nHigh Knees – 3x30s" },
    { day: "Saturday", workout: "Outdoor Activity", details: "Bike Ride / Hiking / Dance – 45 min" },
    { day: "Sunday", workout: "Rest", details: "Stretching or Leisure Walk – 30 min" }
  ]
};



async function loadPlan(goal) {
  const name = localStorage.getItem("userName") || "Anonymous";
  document.getElementById("welcome").textContent = `Hello, ${name}. Here's your ${goal} workout plan:`;

  if (Object.keys(plans).length === 0) {
    const res = await fetch("plans.json");
    plans = await res.json();
  }

  const plan = plans[goal];
  const container = document.getElementById("planContainer");
  container.innerHTML = "";

  plan.forEach((day, index) => {
    const div = document.createElement("div");
    div.className = "day";
    div.innerHTML = `<strong>${day.day}</strong><br>${day.workout}<pre>${day.details}</pre>`;
    container.appendChild(div);
    setTimeout(() => div.classList.add("visible"), index * 120);
  });

  const btn = document.getElementById("downloadBtn");
  btn.style.display = "block";
  setTimeout(() => btn.classList.add("show"), plan.length * 120 + 300);
}

function toggleDarkMode() {
  const isDark = document.body.classList.toggle("dark");
  localStorage.setItem("darkMode", isDark);
}




function exportPDF(goal) {
  const { jsPDF } = window.jspdf;
  const doc = new jsPDF();
  const name = localStorage.getItem("userName") || "Anonymous";
  const plan = plans[goal];
  const date = new Date().toLocaleDateString();

  doc.setFontSize(18);
  doc.text(" Personal Workout Plan", 10, 20);
  doc.setFontSize(12);
  doc.text(`Name: ${name}`, 10, 30);
  doc.text(`Goal: ${goal}`, 10, 37);
  doc.text(`Date: ${date}`, 10, 44);

  let y = 55;
  plan.forEach(day => {
    doc.setFont(undefined, "bold");
    doc.text(`${day.day}: ${day.workout}`, 10, y);
    y += 7;
    doc.setFont(undefined, "normal");
    const lines = doc.splitTextToSize(day.details, 180);
    doc.text(lines, 10, y);
    y += lines.length * 6 + 3;

    if (y > 270) {
      doc.addPage();
      y = 20;
    }
  });

  doc.save(`Workout_Plan_${name}.pdf`);
}

function addIcons(text) {
  return text
    .replace(/Squat|Lunges|Deadlift/gi, "$&")
    .replace(/Push-ups|Bench Press|Plank/gi, "$&")
    .replace(/Run|Jog|Cardio|HIIT|Jump/gi, "$&")
    .replace(/Yoga|Stretch|Mobility/gi, "$&")
    .replace(/Rest/gi, "$&");
}
